package com.empresa;

import com.empresa.config.configuracionDependencia;

public class App {

    public static void main(String[] args) {
        try {
            configuracionDependencia config = new configuracionDependencia(); 
            config.getMenuPrincipal().iniciar();
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }
    }
}
