package com.empresa.servicio;

import com.empresa.modelo.notificacion;

public class notificacionServicio {

    private final notificacion canal;

    public notificacionServicio(notificacion canalcito) {
        this.canal = canalcito;
    }

    public boolean procesar(String mensaje) {
        return canal.enviar(mensaje);
    }

    public String canal() {
        return canal.obtenerCanal();
    }
    
}
