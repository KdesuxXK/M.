
package com.empresa.vista;

import com.empresa.controlador.notificacionControlador;
import com.empresa.vista.core.moduloSistema;


public class correoVista implements moduloSistema{
    
    private final notificacionControlador controlador; 

    public correoVista(notificacionControlador controlador) {
        this.controlador = controlador;
    }

    @Override
    public String obtenerNombre() {
        return "correo electronico"; 
    }

    @Override
    public void ejecutar() {
       controlador.enviar("correo con aunto y cuerpo");
    }
    
    
}
