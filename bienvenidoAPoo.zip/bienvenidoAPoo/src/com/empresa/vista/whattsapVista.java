package com.empresa.vista;

import com.empresa.controlador.notificacionControlador;
import com.empresa.vista.core.moduloSistema;

public class whattsapVista implements moduloSistema{

    
    private final notificacionControlador controlador; 

    public whattsapVista(notificacionControlador controlador) {
        this.controlador = controlador;
    }

    @Override
    public String obtenerNombre() {
        return "enviado whattsap"; 
    }

    @Override
    public void ejecutar() {
        controlador.enviar("guasapeameeeee");
    }
    
    
}
