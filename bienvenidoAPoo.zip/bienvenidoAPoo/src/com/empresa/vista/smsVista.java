package com.empresa.vista;

import com.empresa.controlador.notificacionControlador;
import com.empresa.vista.core.moduloSistema;

public class smsVista implements moduloSistema {

    private final notificacionControlador controlador;

    public smsVista(notificacionControlador controlador) {
        this.controlador = controlador;
    }

    @Override
    public String obtenerNombre() {
        return "sms"; 
    }

    @Override
    public void ejecutar() {
        controlador.enviar("mensaje de texto  antiguuo");
    }

}
