package com.empresa.vista.io;

public class Menu {

    public void mostrarTitulo(String Titulo) {
        System.out.println("\n****" + Titulo + "*****\n");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
