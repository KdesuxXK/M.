package com.empresa.vista.core;

import com.empresa.vista.io.Menu;
import java.util.List;

public class MenuPrincipal {

    private final Menu menu;
    private final List<moduloSistema> Modulos;

    public MenuPrincipal(Menu menu, List<moduloSistema> Modulos) {
        this.menu = menu;
        this.Modulos = Modulos;
    }
    public  void  iniciar(){
        menu.mostrarTitulo("Dios mio q rikooo");
        
        for (moduloSistema Modulo : Modulos) {
            menu.mostrarMensaje("modulo" + Modulo.obtenerNombre());
            Modulo.ejecutar();
            System.out.println("");
        }
        menu.mostrarMensaje("gracias este fue mi primer proyecto completo");
    }

}
