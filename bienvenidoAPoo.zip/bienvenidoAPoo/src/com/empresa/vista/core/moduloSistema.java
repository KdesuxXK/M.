package com.empresa.vista.core;

public interface moduloSistema {

    public String obtenerNombre();

    public void ejecutar();

}
