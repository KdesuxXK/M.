package com.empresa.controlador;

import com.empresa.servicio.notificacionServicio;

public class notificacionControlador {

    private final notificacionServicio servicio;

    public notificacionControlador(notificacionServicio servicio) {
        this.servicio = servicio;
    }
    public void enviar (String mensaje){
        servicio.procesar(mensaje); 
    }

}
