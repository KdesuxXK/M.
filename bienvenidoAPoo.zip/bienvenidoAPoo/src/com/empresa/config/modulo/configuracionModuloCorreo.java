package com.empresa.config.modulo;

import com.empresa.controlador.notificacionControlador;
import com.empresa.modelo.correo;
import com.empresa.servicio.notificacionServicio;
import com.empresa.vista.core.moduloSistema;
import com.empresa.vista.correoVista;
import com.empresa.vista.io.Menu;

public class configuracionModuloCorreo implements ModuloConfigurable{

    @Override
    public moduloSistema construirviSistema(Menu menu) {
        notificacionServicio servicio = new notificacionServicio(new correo());
        notificacionControlador controlador = new notificacionControlador(servicio); 
        return  new correoVista(controlador); 
    }

    
    
    
  
}
