
package com.empresa.config.modulo;

import com.empresa.controlador.notificacionControlador;
import com.empresa.modelo.sms;
import com.empresa.servicio.notificacionServicio;
import com.empresa.vista.core.moduloSistema;
import com.empresa.vista.io.Menu;
import com.empresa.vista.smsVista;


public class configuracionModuloSms implements ModuloConfigurable{

    @Override
    public moduloSistema construirviSistema(Menu menu) {
        notificacionServicio servicio = new notificacionServicio(new sms()); 
        notificacionControlador controlador = new notificacionControlador(servicio); 
        smsVista vista = new smsVista(controlador); 
        return vista; 
    }
    
}
