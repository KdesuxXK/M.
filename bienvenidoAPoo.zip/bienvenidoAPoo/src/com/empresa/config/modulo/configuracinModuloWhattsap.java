package com.empresa.config.modulo;

import com.empresa.controlador.notificacionControlador;
import com.empresa.modelo.WhatsApp;
import com.empresa.servicio.notificacionServicio;
import com.empresa.vista.core.moduloSistema;
import com.empresa.vista.io.Menu;
import com.empresa.vista.whattsapVista;

public class configuracinModuloWhattsap implements ModuloConfigurable{

    @Override
    public moduloSistema construirviSistema(Menu menu) {
        notificacionServicio servicio = new notificacionServicio(new WhatsApp()); 
        notificacionControlador controlador = new notificacionControlador(servicio); 
        whattsapVista vista = new whattsapVista(controlador); 
        
        return vista; 
    }

}
