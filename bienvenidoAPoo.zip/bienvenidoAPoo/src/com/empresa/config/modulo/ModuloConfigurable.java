package com.empresa.config.modulo;

import com.empresa.vista.core.moduloSistema;
import com.empresa.vista.io.Menu;


public interface ModuloConfigurable {
    
    
   public moduloSistema construirviSistema(Menu menu); 
}
