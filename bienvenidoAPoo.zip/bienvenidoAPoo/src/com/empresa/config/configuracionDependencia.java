package com.empresa.config;

import com.empresa.config.modulo.configuracinModuloWhattsap;
import com.empresa.config.modulo.configuracionModuloCorreo;
import com.empresa.config.modulo.configuracionModuloSms;
import com.empresa.vista.core.MenuPrincipal;
import com.empresa.vista.core.moduloSistema;
import com.empresa.vista.io.Menu;
import java.util.ArrayList;
import java.util.List;

public class configuracionDependencia {
    private final Menu menu; 
    private final MenuPrincipal menuPrincipal; 

    public configuracionDependencia() {
        menu = new Menu(); 
        List<moduloSistema> modulos = new ArrayList<>(); 
        
        // configuracion correo
        configuracionModuloCorreo moduloCorreo= new configuracionModuloCorreo(); 
        modulos.add(moduloCorreo.construirviSistema(menu)); 
      
        // configguracion sms
        
        configuracionModuloSms MOduloSms= new configuracionModuloSms(); 
        modulos.add(MOduloSms.construirviSistema(menu)); 
        // configuracion whattsap
        configuracinModuloWhattsap moduloWhattsap = new configuracinModuloWhattsap(); 
        modulos.add(moduloCorreo.construirviSistema(menu));
        
        menuPrincipal = new MenuPrincipal(menu, modulos); 
        
        
    }
    public  MenuPrincipal getMenuPrincipal (){
    
    return menuPrincipal; 
    }
}
