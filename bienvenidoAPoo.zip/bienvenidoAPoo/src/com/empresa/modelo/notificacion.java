package com.empresa.modelo;

public interface notificacion {

    public String obtenerCanal();

    public boolean enviar(String mensaje);

}
