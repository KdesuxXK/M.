package com.empresa.modelo;

public class sms implements notificacion {

    @Override
    public String obtenerCanal() {
        return "SMS"; 
    }

    @Override
    public boolean enviar(String mensaje) {
        System.out.println("enviandoo por "+ obtenerCanal()+  ": "+ mensaje);
        return true; 
    }

}
