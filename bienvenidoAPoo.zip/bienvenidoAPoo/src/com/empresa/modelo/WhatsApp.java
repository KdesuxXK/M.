package com.empresa.modelo;

public class WhatsApp implements notificacion{

    @Override
    public String obtenerCanal() {
        return "WhatsApp"; 
    }

    @Override
    public boolean enviar(String mensaje) {
        System.out.println("enviando por "+obtenerCanal()+": "+ mensaje);
        return true; 
    }
    
    
    
    
    
}
