package com.empresa.modelo;

public class correo implements notificacion {

    @Override
    public String obtenerCanal() {
        return "correo electronico"; 
    }

    @Override
    public boolean enviar(String mensaje) {
        System.out.println("enviandoo por " + obtenerCanal() + ": " +mensaje );
        return true; 
    }
    
}
